package com.company.enums;

public enum UserStatus {
    SEND_CONTACT
}
