package com.company.enums;

public enum OrderStatus {
    NOT_COMMITTED,
    COMMITTED,
    CANCELED,
    PAID,
    COMPLETED
}
